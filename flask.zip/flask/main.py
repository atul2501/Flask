from flask import Flask,render_template
'''
It creates an instance of the flask class,
which will be your WSGI(Web server Gateway Interface) application.
'''

app=Flask(__name__)

@app.route("/")

def Welcome():
    return render_template('home.html')

@app.route("/index")

def index():
    return render_template('index.html')

if __name__=="__main__":from flask import Flask, render_template

# Create an instance of the Flask class
app = Flask(__name__)

# Define a route for the root URL
@app.route("/")
def welcome():
    """Renders the home.html template"""
    return render_template('home.html')

# Define a route for the index URL
@app.route("/index")
def index():
    """Renders the index.html template"""
    return render_template('index.html')

@app.route("/about")
def about():
    "Render the about.html template"
    return  render_template('about.html')

if __name__ == "__main__":
    # Run the application in debug mode
    app.run(debug=True )
